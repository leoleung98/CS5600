/*
* cipher.h
* 
* Leo Liang / CS5600 / Northeastern University
* Spring 2023 / Feb 8, 2023
*
*/

void *run(void *arg);